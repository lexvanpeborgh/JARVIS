const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

const DB_NAME = "jarvis-pwa-db";
const DB_VERSION = 1;
const STORES = ["messages","memories","tasks","events","kv"];
let db;
let sessionId = crypto.randomUUID();
let pendingFile = null;
let mediaRecorder = null;
let mediaChunks = [];
let recordingStarted = 0;

const settings = {
  backendURL: localStorage.getItem("jarvis-backend") || location.origin,
  relayToken: localStorage.getItem("jarvis-relay-token") || "",
  userName: localStorage.getItem("jarvis-user-name") || "",
  model: localStorage.getItem("jarvis-model") || "gpt-5.2",
  speak: localStorage.getItem("jarvis-speak") !== "false"
};

function openDB(){
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open(DB_NAME,DB_VERSION);
    req.onupgradeneeded=()=>{
      const d=req.result;
      if(!d.objectStoreNames.contains("messages")){
        const s=d.createObjectStore("messages",{keyPath:"id"});
        s.createIndex("createdAt","createdAt");
        s.createIndex("sessionId","sessionId");
      }
      for(const name of ["memories","tasks","events"]){
        if(!d.objectStoreNames.contains(name)){
          const s=d.createObjectStore(name,{keyPath:"id"});
          s.createIndex("createdAt","createdAt");
        }
      }
      if(!d.objectStoreNames.contains("kv")) d.createObjectStore("kv",{keyPath:"key"});
    };
    req.onsuccess=()=>{db=req.result;resolve(db)};
    req.onerror=()=>reject(req.error);
  })
}
function store(name,mode="readonly"){return db.transaction(name,mode).objectStore(name)}
function put(name,obj){return new Promise((res,rej)=>{const r=store(name,"readwrite").put(obj);r.onsuccess=()=>res(obj);r.onerror=()=>rej(r.error)})}
function del(name,id){return new Promise((res,rej)=>{const r=store(name,"readwrite").delete(id);r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
function all(name){return new Promise((res,rej)=>{const r=store(name).getAll();r.onsuccess=()=>res(r.result||[]);r.onerror=()=>rej(r.error)})}
function getKV(key){return new Promise((res,rej)=>{const r=store("kv").get(key);r.onsuccess=()=>res(r.result?.value);r.onerror=()=>rej(r.error)})}
function setKV(key,value){return put("kv",{key,value})}
const nowISO=()=>new Date().toISOString();

function escapeHTML(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function tokenize(s){return new Set((String(s).toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu,"").match(/[\p{L}\p{N}]{3,}/gu)||[]))}
function fmtDate(v){return new Intl.DateTimeFormat("nl-BE",{weekday:"short",day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"}).format(new Date(v))}
function fmtShort(v){return new Intl.DateTimeFormat("nl-BE",{day:"numeric",month:"short"}).format(new Date(v))}

async function relevantMemories(query,limit=8){
  const memories=await all("memories"), q=tokenize(query);
  const scored=memories.map(m=>{
    const t=tokenize(m.text);let score=0;
    for(const w of q) if(t.has(w)) score+=3;
    if(["preference","goal","profile","routine"].includes(m.category)) score++;
    return {m,score};
  }).sort((a,b)=>b.score-a.score);
  let chosen=scored.filter(x=>x.score>0).slice(0,limit).map(x=>x.m);
  if(chosen.length<Math.min(4,memories.length)){
    const ids=new Set(chosen.map(x=>x.id));
    chosen.push(...memories.filter(x=>!ids.has(x.id)).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,4-chosen.length));
  }
  return chosen.slice(0,limit);
}
async function recentMessages(limit=14){
  return (await all("messages")).filter(m=>m.sessionId===sessionId).sort((a,b)=>a.createdAt.localeCompare(b.createdAt)).slice(-limit);
}
async function historyMatches(query,limit=8){
  const q=tokenize(query);
  return (await all("messages")).filter(m=>m.sessionId!==sessionId).map(m=>{
    const t=tokenize(m.text);let score=0;for(const w of q)if(t.has(w))score++;
    return {m,score};
  }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score||b.m.createdAt.localeCompare(a.m.createdAt)).slice(0,limit).map(x=>x.m);
}

function showPage(name){
  $$(".page").forEach(p=>p.classList.toggle("active",p.dataset.page===name));
  $$(".tabbar [data-tab]").forEach(b=>b.classList.toggle("active",b.dataset.tab===name));
  if(name==="chat") setTimeout(()=>window.scrollTo({top:document.body.scrollHeight,behavior:"smooth"}),40);
}
$$("[data-tab]").forEach(b=>b.onclick=()=>showPage(b.dataset.tab));
$$("[data-go]").forEach(b=>b.onclick=()=>showPage(b.dataset.go));
$$("[data-draft]").forEach(b=>b.onclick=()=>{$("#promptInput").value=b.dataset.draft;showPage("chat");$("#promptInput").focus()});

$$(".segment [data-more]").forEach(b=>b.onclick=()=>{
  $$(".segment [data-more]").forEach(x=>x.classList.toggle("active",x===b));
  $$(".more-pane").forEach(x=>x.classList.toggle("active",x.dataset.morePane===b.dataset.more));
});

async function refresh(){
  const [memories,tasks,events,messages]=await Promise.all([all("memories"),all("tasks"),all("events"),all("messages")]);
  $("#memoryChip").textContent=`${memories.length} memories`;
  $("#memoryCount").textContent=`${memories.length} durable memories`;
  $("#taskChip").textContent=`${tasks.filter(t=>!t.done).length} tasks`;
  $("#openTasks").textContent=`${tasks.filter(t=>!t.done).length} open`;

  const future=events.filter(e=>new Date(e.when)>=new Date()).sort((a,b)=>new Date(a.when)-new Date(b.when));
  $("#nextEvent").innerHTML=future[0]?`<b>${escapeHTML(future[0].title)}</b><br><span class="empty">${fmtDate(future[0].when)}</span>`:"Geen geplande afspraak.";

  $("#recentList").innerHTML=messages.slice().sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,4).map(m=>`<div>${escapeHTML(m.text).slice(0,110)}</div>`).join("")||'<div class="empty">Nog geen gesprekken.</div>';

  $("#memoryList").innerHTML=memories.slice().sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).map(m=>`
    <div class="list-card">
      <div class="meta"><span>${escapeHTML((m.category||"general").toUpperCase())}</span><span>${fmtShort(m.createdAt)}</span></div>
      <div class="body">${escapeHTML(m.text)}</div>
      <div class="actions"><button onclick="deleteMemory('${m.id}')">Delete</button></div>
    </div>`).join("")||'<div class="empty">Memory Core is leeg. Zeg in Chat: “onthoud dat …”</div>';

  $("#taskList").innerHTML=tasks.slice().sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).map(t=>`
    <div class="list-card ${t.done?"done":""}">
      <div class="body">${t.done?"✓":"○"} ${escapeHTML(t.title)}</div>
      <div class="actions"><button onclick="toggleTask('${t.id}')">${t.done?"Undo":"Done"}</button><button onclick="deleteTask('${t.id}')">Delete</button></div>
    </div>`).join("")||'<div class="empty">Geen taken.</div>';

  $("#agendaList").innerHTML=events.slice().sort((a,b)=>new Date(a.when)-new Date(b.when)).map(e=>`
    <div class="list-card">
      <div class="meta"><span>EVENT</span><span>${fmtDate(e.when)}</span></div>
      <div class="body">${escapeHTML(e.title)}</div>
      <div class="actions"><button onclick="deleteEvent('${e.id}')">Delete</button></div>
    </div>`).join("")||'<div class="empty">Geen afspraken.</div>';

  const current=messages.filter(m=>m.sessionId===sessionId).sort((a,b)=>a.createdAt.localeCompare(b.createdAt));
  $("#messages").innerHTML=current.map(m=>`
    <div class="bubble ${m.role==="user"?"user":"ai"}">
      ${m.imageData?`<img src="${m.imageData}" alt="generated image">`:""}
      ${m.text?escapeHTML(m.text):""}
    </div>`).join("")||'<div class="bubble ai">JARVIS online. Geef me een opdracht, zoek iets op of zeg wat ik moet onthouden.</div>';

  $("#dataStats").textContent=`${messages.length} chat messages · ${memories.length} memories · ${tasks.length} tasks · ${events.length} events`;
}

window.deleteMemory=async id=>{await del("memories",id);refresh()};
window.deleteTask=async id=>{await del("tasks",id);refresh()};
window.deleteEvent=async id=>{await del("events",id);refresh()};
window.toggleTask=async id=>{const items=await all("tasks"),t=items.find(x=>x.id===id);if(t){t.done=!t.done;await put("tasks",t);refresh()}};

$("#taskAddBtn").onclick=async()=>{
  const title=$("#taskInput").value.trim();if(!title)return;
  await put("tasks",{id:crypto.randomUUID(),title,done:false,createdAt:nowISO()});
  $("#taskInput").value="";refresh();
};
$("#taskInput").onkeydown=e=>{if(e.key==="Enter")$("#taskAddBtn").click()};

let modalMode="memory";
function openModal(mode){
  modalMode=mode;$("#modalTitle").textContent=mode==="memory"?"Add Memory":"Add Event";
  $("#modalTextLabel").firstChild.textContent=mode==="memory"?"What should JARVIS remember?":"Event title";
  $("#modalText").value="";
  $("#modalDateLabel").classList.toggle("hidden",mode!=="event");
  if(mode==="event"){
    const d=new Date(Date.now()+3600000);d.setMinutes(d.getMinutes()-d.getTimezoneOffset());
    $("#modalDate").value=d.toISOString().slice(0,16);
  }
  $("#modal").showModal();
}
$("#addMemoryBtn").onclick=()=>openModal("memory");
$("#eventAddBtn").onclick=()=>openModal("event");
$("#modalSave").onclick=async e=>{
  const text=$("#modalText").value.trim();if(!text)return;
  if(modalMode==="memory")await put("memories",{id:crypto.randomUUID(),text,category:"general",createdAt:nowISO()});
  else await put("events",{id:crypto.randomUUID(),title:text,when:new Date($("#modalDate").value).toISOString(),createdAt:nowISO()});
  refresh();
};

$("#newChatBtn").onclick=async()=>{sessionId=crypto.randomUUID();await setKV("lastSession",sessionId);refresh()};
$("#notesArea").oninput=()=>setKV("notes",$("#notesArea").value);

$("#attachBtn").onclick=()=>$("#fileInput").click();
$("#fileInput").onchange=e=>{
  pendingFile=e.target.files?.[0]||null;
  $("#attachmentBar").classList.toggle("hidden",!pendingFile);
  $("#attachmentName").textContent=pendingFile?.name||"";
};
$("#clearAttachmentBtn").onclick=()=>{pendingFile=null;$("#fileInput").value="";$("#attachmentBar").classList.add("hidden")};

async function fileToAttachment(file){
  if(!file)return null;
  if(file.size>20*1024*1024)throw new Error("Bestand is groter dan 20 MB.");
  return {filename:file.name,mimeType:file.type||"application/octet-stream",base64:await blobToBase64(file)};
}
function blobToBase64(blob){
  return new Promise((resolve,reject)=>{
    const r=new FileReader();r.onload=()=>resolve(String(r.result).split(",")[1]);r.onerror=()=>reject(r.error);r.readAsDataURL(blob);
  })
}
function apiURL(path){
  const base=(settings.backendURL||location.origin).replace(/\/+$/,"");
  return base+path;
}
async function api(path,payload){
  const headers={"Content-Type":"application/json"};
  if(settings.relayToken)headers.Authorization=`Bearer ${settings.relayToken}`;
  const r=await fetch(apiURL(path),{method:"POST",headers,body:JSON.stringify(payload)});
  const text=await r.text();let data;try{data=JSON.parse(text)}catch{data={error:text}}
  if(!r.ok)throw new Error(data.error||`HTTP ${r.status}`);
  return data;
}
async function health(){
  const headers={};if(settings.relayToken)headers.Authorization=`Bearer ${settings.relayToken}`;
  const r=await fetch(apiURL("/api/health"),{headers});const data=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error(data.error||`HTTP ${r.status}`);return data;
}

async function sendMessage(){
  const text=$("#promptInput").value.trim();
  if(!text&&!pendingFile)return;
  const display=text||"Analyseer het bijgevoegde bestand.";
  await put("messages",{id:crypto.randomUUID(),role:"user",text:display,createdAt:nowISO(),sessionId});
  $("#promptInput").value="";
  const file=pendingFile;pendingFile=null;$("#fileInput").value="";$("#attachmentBar").classList.add("hidden");
  await refresh();showPage("chat");
  const thinking=document.createElement("div");thinking.className="bubble ai thinking";thinking.textContent="JARVIS is thinking…";$("#messages").appendChild(thinking);
  setThinking(true);
  try{
    const [mem,recent,hist,attachment]=await Promise.all([
      relevantMemories(display),
      recentMessages(),
      historyMatches(display),
      fileToAttachment(file)
    ]);
    const result=await api("/api/chat",{
      message:display,model:settings.model,userName:settings.userName,
      memoryContext:mem.map(x=>x.text),
      recentMessages:recent.map(x=>({role:x.role,text:x.text})),
      historyMatches:hist.map(x=>({role:x.role,text:x.text})),
      localTime:new Date().toISOString(),attachment
    });
    await executeActions(result.actions||[]);
    await put("messages",{id:crypto.randomUUID(),role:"assistant",text:result.text||"Done.",createdAt:nowISO(),sessionId});
    if(settings.speak)speak(result.text||"");
  }catch(err){
    await put("messages",{id:crypto.randomUUID(),role:"assistant",text:`Error: ${err.message}`,createdAt:nowISO(),sessionId});
  }finally{
    setThinking(false);refresh();
  }
}
$("#sendBtn").onclick=sendMessage;
$("#promptInput").onkeydown=e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMessage()}};

async function executeActions(actions){
  for(const a of actions){
    if(a.type==="save_memory"&&a.text){
      const ms=await all("memories");
      if(!ms.some(m=>m.text.toLowerCase()===a.text.toLowerCase()))await put("memories",{id:crypto.randomUUID(),text:a.text,category:a.category||"general",createdAt:nowISO()});
    }else if(a.type==="add_task"&&a.title){
      await put("tasks",{id:crypto.randomUUID(),title:a.title,done:false,createdAt:nowISO()});
    }else if(a.type==="add_event"&&a.title&&a.when){
      await put("events",{id:crypto.randomUUID(),title:a.title,when:a.when,createdAt:nowISO()});
    }else if(a.type==="save_note"&&a.text){
      const old=(await getKV("notes"))||"",stamp=new Date().toLocaleString("nl-BE");
      await setKV("notes",(old?old+"\n":"")+`[${stamp}] ${a.text}`);$("#notesArea").value=await getKV("notes");
    }else if(a.type==="open_url"&&a.url&&/^https?:\/\//i.test(a.url)){
      window.open(a.url,"_blank","noopener");
    }
  }
}

async function generateImage(){
  const prompt=$("#promptInput").value.trim();if(!prompt){alert("Typ eerst wat voor afbeelding je wilt.");return}
  $("#promptInput").value="";showPage("chat");setThinking(true);
  await put("messages",{id:crypto.randomUUID(),role:"user",text:`[Generate image] ${prompt}`,createdAt:nowISO(),sessionId});
  await refresh();
  try{
    const result=await api("/api/image",{prompt});
    const data=`data:${result.mimeType||"image/png"};base64,${result.base64}`;
    await put("messages",{id:crypto.randomUUID(),role:"assistant",text:"Image generated.",imageData:data,createdAt:nowISO(),sessionId});
  }catch(err){
    await put("messages",{id:crypto.randomUUID(),role:"assistant",text:`Image error: ${err.message}`,createdAt:nowISO(),sessionId});
  }finally{setThinking(false);refresh()}
}
$("#imageBtn").onclick=generateImage;

function setThinking(v){
  $("#reactor").classList.toggle("thinking",v);$("#coreState").textContent=v?"THINKING":"READY";$("#coreHint").textContent=v?"PROCESSING":"TAP TO SPEAK";
}

function speak(text){
  if(!("speechSynthesis"in window)||!text)return;
  speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text.replace(/https?:\/\/\S+/g,""));u.lang="nl-BE";u.rate=1.02;speechSynthesis.speak(u);
}

async function toggleRecording(){
  if(mediaRecorder&&mediaRecorder.state==="recording"){mediaRecorder.stop();return}
  if(!navigator.mediaDevices?.getUserMedia){alert("Microfoon wordt hier niet ondersteund.");return}
  try{
    const stream=await navigator.mediaDevices.getUserMedia({audio:true});
    const types=["audio/mp4","audio/webm;codecs=opus","audio/webm"];
    const mime=types.find(t=>MediaRecorder.isTypeSupported?.(t))||"";
    mediaChunks=[];
    mediaRecorder=new MediaRecorder(stream,mime?{mimeType:mime}:undefined);
    mediaRecorder.ondataavailable=e=>{if(e.data.size)mediaChunks.push(e.data)};
    mediaRecorder.onstop=async()=>{
      stream.getTracks().forEach(t=>t.stop());
      const blob=new Blob(mediaChunks,{type:mediaRecorder.mimeType||"audio/webm"});
      setListening(false);
      try{
        $("#coreState").textContent="TRANSCRIBING";$("#coreHint").textContent="PLEASE WAIT";
        const result=await api("/api/transcribe",{mimeType:blob.type||"audio/webm",base64:await blobToBase64(blob)});
        $("#promptInput").value=result.text||"";
        $("#liveTranscript").textContent=result.text||"";
        if(result.text)sendMessage();
      }catch(err){alert("Voice error: "+err.message)}
      finally{setListening(false)}
    };
    recordingStarted=Date.now();mediaRecorder.start();setListening(true);
    setTimeout(()=>{if(mediaRecorder?.state==="recording")mediaRecorder.stop()},30000);
  }catch(err){alert("Microfoon kon niet worden gestart: "+err.message)}
}
function setListening(v){
  $("#reactor").classList.toggle("listening",v);$("#coreState").textContent=v?"LISTENING":"READY";$("#coreHint").textContent=v?"TAP TO STOP":"TAP TO SPEAK";$("#micBtn").textContent=v?"■":"🎙";$("#liveTranscript").classList.toggle("hidden",!v);
  if(v)$("#liveTranscript").textContent="Ik luister…";
}
$("#reactorBtn").onclick=toggleRecording;$("#micBtn").onclick=toggleRecording;

$("#backendURL").value=settings.backendURL;$("#relayToken").value=settings.relayToken;$("#userName").value=settings.userName;$("#modelName").value=settings.model;$("#speakToggle").checked=settings.speak;
$("#saveSettingsBtn").onclick=()=>{
  settings.backendURL=$("#backendURL").value.trim()||location.origin;
  settings.relayToken=$("#relayToken").value.trim();
  settings.userName=$("#userName").value.trim();
  settings.model=$("#modelName").value.trim()||"gpt-5.2";
  settings.speak=$("#speakToggle").checked;
  localStorage.setItem("jarvis-backend",settings.backendURL);localStorage.setItem("jarvis-relay-token",settings.relayToken);localStorage.setItem("jarvis-user-name",settings.userName);localStorage.setItem("jarvis-model",settings.model);localStorage.setItem("jarvis-speak",String(settings.speak));
  $("#connectionStatus").textContent="Instellingen opgeslagen.";$("#connectionStatus").className="status ok";
};
$("#testBtn").onclick=async()=>{
  $("#connectionStatus").textContent="Testing…";$("#connectionStatus").className="status";
  try{const r=await health();$("#connectionStatus").textContent=`Connected${r.model?" · "+r.model:""}`;$("#connectionStatus").className="status ok"}
  catch(err){$("#connectionStatus").textContent=err.message;$("#connectionStatus").className="status bad"}
};
$("#installHelpBtn").onclick=()=>$("#installDialog").showModal();

$("#clearMemoryBtn").onclick=async()=>{
  if(!confirm("Alle Memory Core-items verwijderen?"))return;
  const ms=await all("memories");for(const m of ms)await del("memories",m.id);refresh();
};
$("#exportBtn").onclick=async()=>{
  const data={exportedAt:nowISO(),messages:await all("messages"),memories:await all("memories"),tasks:await all("tasks"),events:await all("events"),notes:await getKV("notes")||""};
  const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:"application/json"}));a.download=`JARVIS-backup-${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(a.href);
};

function updateGreeting(){
  const h=new Date().getHours(),g=h<12?"GOEDEMORGEN":h<18?"GOEDEMIDDAG":"GOEDE AVOND";
  $("#greeting").textContent=settings.userName?`${g}, ${settings.userName.toUpperCase()}`:g;
}
setInterval(updateGreeting,60000);

(async function init(){
  await openDB();
  sessionId=(await getKV("lastSession"))||sessionId;await setKV("lastSession",sessionId);
  $("#notesArea").value=(await getKV("notes"))||"";
  updateGreeting();await refresh();
  if("serviceWorker"in navigator)navigator.serviceWorker.register("/sw.js").catch(()=>{});
  const standalone=window.matchMedia("(display-mode: standalone)").matches||window.navigator.standalone===true;
  if(!standalone&&!localStorage.getItem("jarvis-install-hint-seen")){
    setTimeout(()=>{$("#installDialog").showModal();localStorage.setItem("jarvis-install-hint-seen","1")},1200);
  }
})();
