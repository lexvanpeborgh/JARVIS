# JARVIS iPhone PWA

This is the free-to-install iPhone version.

It is a **Progressive Web App (PWA)**:
- hosted as a normal HTTPS website,
- installed from Safari using **Add to Home Screen**,
- opens in standalone/fullscreen mode,
- has its own JARVIS icon,
- does not require the Apple Developer Program,
- keeps chats, Memory Core, tasks, agenda and notes locally in IndexedDB on the device.

## What works

- JARVIS sci-fi mobile HUD
- install on iPhone Home Screen
- persistent local chat history
- persistent Memory Core
- search/retrieval across older chats
- tasks
- agenda
- notes
- voice recording and server-side speech transcription
- spoken replies using browser speech synthesis
- files/images/PDF/text/CSV/JSON
- OpenAI Responses API
- web search
- image generation
- offline loading of the interface after first load
- data backup export

## What is different from a native iOS app

A PWA does not get every native iOS permission/API. In particular, continuous
background listening, arbitrary iPhone control and unrestricted background
execution are not available.

## Security

Never put your OpenAI API key in `app.js`.

This project includes `/api` serverless functions. Deploy the whole repository
to Vercel and store the OpenAI key in Vercel Environment Variables. The browser
only talks to your own `/api` endpoints.

## AI cost

Apple Developer membership is not required.

OpenAI API usage is separate from ChatGPT Plus and may incur API charges. The
website itself can be hosted on a free hosting tier.

## Install flow

1. Deploy to Vercel.
2. Open the resulting HTTPS URL in Safari on iPhone.
3. Share → Add to Home Screen.
4. Open JARVIS from the Home Screen.
5. Settings can use the same site URL as Backend URL, or leave the default.
