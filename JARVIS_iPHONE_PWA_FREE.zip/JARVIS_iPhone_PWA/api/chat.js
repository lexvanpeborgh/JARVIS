import { auth, send, openAI, extractText } from "./_common.js";

function tools(){
  return [
    {type:"web_search"},
    {type:"function",name:"save_memory",description:"Save a durable user-provided fact, preference, goal, recurring routine, project fact, or something the user explicitly asks to remember. Avoid fleeting details. Do not save sensitive personal data unless explicitly requested.",strict:true,parameters:{type:"object",properties:{text:{type:"string"},category:{type:"string",enum:["preference","goal","profile","routine","project","general"]}},required:["text","category"],additionalProperties:false}},
    {type:"function",name:"add_task",description:"Add a task to the user's local JARVIS task list.",strict:true,parameters:{type:"object",properties:{title:{type:"string"}},required:["title"],additionalProperties:false}},
    {type:"function",name:"add_event",description:"Add an event to the user's local JARVIS agenda. Use ISO 8601 date-time.",strict:true,parameters:{type:"object",properties:{title:{type:"string"},when:{type:"string"}},required:["title","when"],additionalProperties:false}},
    {type:"function",name:"save_note",description:"Append text to the user's local JARVIS notes.",strict:true,parameters:{type:"object",properties:{text:{type:"string"}},required:["text"],additionalProperties:false}},
    {type:"function",name:"open_url",description:"Open a safe http/https URL only if the user explicitly asked to open a page.",strict:true,parameters:{type:"object",properties:{url:{type:"string"}},required:["url"],additionalProperties:false}}
  ];
}
function action(call){
  let a={};try{a=JSON.parse(call.arguments||"{}")}catch{}
  if(call.name==="save_memory")return{type:"save_memory",text:a.text,category:a.category};
  if(call.name==="add_task")return{type:"add_task",title:a.title};
  if(call.name==="add_event")return{type:"add_event",title:a.title,when:a.when};
  if(call.name==="save_note")return{type:"save_note",text:a.text};
  if(call.name==="open_url")return{type:"open_url",url:a.url};
  return null;
}
export default async function handler(req,res){
  if(req.method!=="POST")return send(res,405,{error:"Method not allowed"});
  if(!auth(req))return send(res,401,{error:"Unauthorized"});
  try{
    const b=req.body||{}, model=b.model || process.env.OPENAI_MODEL || "gpt-5.2";
    const input=[];
    for(const m of (b.recentMessages||[]).slice(-14))input.push({role:m.role==="assistant"?"assistant":"user",content:String(m.text||"")});
    const content=[{type:"input_text",text:String(b.message||"")}];
    if(b.attachment?.base64){
      const dataURL=`data:${b.attachment.mimeType||"application/octet-stream"};base64,${b.attachment.base64}`;
      if(String(b.attachment.mimeType||"").startsWith("image/"))content.push({type:"input_image",image_url:dataURL,detail:"auto"});
      else content.push({type:"input_file",file_data:dataURL,filename:b.attachment.filename||"attachment"});
    }
    input.push({role:"user",content});
    const memories=(b.memoryContext||[]).map(x=>`- ${x}`).join("\n")||"(none)";
    const old=(b.historyMatches||[]).map(x=>`- ${x.role}: ${x.text}`).join("\n")||"(none)";
    const instructions=`You are JARVIS, a capable personal AI assistant in an installable iPhone web app.
Default language: Dutch unless the user requests otherwise. Be practical, accurate and conversational.
${b.userName?`The user's preferred name is ${b.userName}.`:""}
Local time from the device: ${b.localTime||new Date().toISOString()}
Use web_search when current public information materially improves the answer.
Function tools request local actions executed by the user's device. Never claim a local action happened unless you called its tool.
Save durable memories when explicitly requested or clearly useful; avoid fleeting details and sensitive data unless explicitly asked.
Relevant Memory Core:
${memories}
Relevant older local chat matches:
${old}`;
    let response=await openAI("/v1/responses",{model,instructions,input,tools:tools(),store:true});
    const actions=[];let loops=0;
    while(loops<5){
      const calls=(response.output||[]).filter(x=>x.type==="function_call");
      if(!calls.length)break;
      const outputs=calls.map(c=>{
        const a=action(c);if(a)actions.push(a);
        return{type:"function_call_output",call_id:c.call_id,output:JSON.stringify({ok:true,queued_for_device:true})}
      });
      response=await openAI("/v1/responses",{model,instructions,previous_response_id:response.id,input:outputs,tools:tools(),store:true});
      loops++;
    }
    return send(res,200,{text:extractText(response)||(actions.length?"Done.":"No text response."),actions});
  }catch(e){return send(res,e.status||500,{error:e.message||"Server error"})}
}