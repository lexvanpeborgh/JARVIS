import { auth, send } from "./_common.js";
export default async function handler(req,res){
  if(req.method!=="GET") return send(res,405,{error:"Method not allowed"});
  if(!auth(req)) return send(res,401,{error:"Unauthorized"});
  return send(res,200,{ok:true,model:process.env.OPENAI_MODEL || "configured"});
}