import { auth, send } from "./_common.js";
export const config = { api: { bodyParser: { sizeLimit: "25mb" } } };
export default async function handler(req,res){
  if(req.method!=="POST")return send(res,405,{error:"Method not allowed"});
  if(!auth(req))return send(res,401,{error:"Unauthorized"});
  try{
    if(!process.env.OPENAI_API_KEY)throw new Error("OPENAI_API_KEY is not configured on the server.");
    const base64=String(req.body?.base64||"");if(!base64)return send(res,400,{error:"Missing audio"});
    const bytes=Buffer.from(base64,"base64");if(bytes.length>20*1024*1024)return send(res,413,{error:"Audio too large"});
    const mime=String(req.body?.mimeType||"audio/webm");
    const ext=mime.includes("mp4")?"m4a":mime.includes("wav")?"wav":"webm";
    const form=new FormData();
    form.append("model",process.env.OPENAI_TRANSCRIBE_MODEL||"gpt-4o-mini-transcribe");
    form.append("file",new Blob([bytes],{type:mime}),`voice.${ext}`);
    const r=await fetch("https://api.openai.com/v1/audio/transcriptions",{method:"POST",headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`},body:form});
    const text=await r.text();let data;try{data=JSON.parse(text)}catch{data={error:{message:text}}}
    if(!r.ok)throw Object.assign(new Error(data?.error?.message||text),{status:r.status});
    return send(res,200,{text:data.text||""});
  }catch(e){return send(res,e.status||500,{error:e.message||"Transcription error"})}
}