export function auth(req) {
  const secret = process.env.JARVIS_SHARED_SECRET || "";
  if (!secret) return true;
  return req.headers.authorization === `Bearer ${secret}`;
}
export function send(res, status, body) {
  res.status(status).json(body);
}
export async function openAI(path, payload, extraHeaders = {}) {
  if (!process.env.OPENAI_API_KEY) throw new Error("OPENAI_API_KEY is not configured on the server.");
  const r = await fetch(`https://api.openai.com${path}`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
      "Content-Type": "application/json",
      ...extraHeaders
    },
    body: JSON.stringify(payload)
  });
  const text = await r.text();
  let data; try { data = JSON.parse(text); } catch { data = { raw: text }; }
  if (!r.ok) {
    const e = new Error(data?.error?.message || text || `OpenAI HTTP ${r.status}`);
    e.status = r.status;
    throw e;
  }
  return data;
}
export function extractText(response) {
  const parts = [], sources = new Map();
  for (const item of response.output || []) {
    if (item.type !== "message") continue;
    for (const c of item.content || []) {
      if (c.type === "output_text" && c.text) parts.push(c.text);
      for (const a of c.annotations || []) if (a.type === "url_citation" && a.url) sources.set(a.url, a.title || a.url);
    }
  }
  let text = parts.join("");
  if (sources.size) {
    text += "\n\nSources:";
    for (const [url,title] of sources) text += `\n• ${title} — ${url}`;
  }
  return text;
}
