import { auth, send, openAI } from "./_common.js";
export default async function handler(req,res){
  if(req.method!=="POST")return send(res,405,{error:"Method not allowed"});
  if(!auth(req))return send(res,401,{error:"Unauthorized"});
  try{
    const prompt=String(req.body?.prompt||"").trim();if(!prompt)return send(res,400,{error:"Missing prompt"});
    const result=await openAI("/v1/images/generations",{model:process.env.OPENAI_IMAGE_MODEL||"gpt-image-1",prompt,size:"1024x1024",n:1});
    const item=result.data?.[0];if(!item?.b64_json)return send(res,500,{error:"No image data returned"});
    return send(res,200,{base64:item.b64_json,mimeType:"image/png"});
  }catch(e){return send(res,e.status||500,{error:e.message||"Image error"})}
}